function setup() {
  createCanvas(600, 400);
}
let x = 300;
let y = 200;
let velocidadexBolinha = 2;
let velocidadeyBolinha = 2;
function draw() {
  background(0);
  circle(x, y, 20);
  x += velocidadexBolinha;
  y += velocidadeyBolinha;
  if (y > height) {
    velocidadeyBolinha = -2;
  }
  if (y < 0) {
    velocidadeyBolinha = 2;
  }
  if (x > width) {
    velocidadexBolinha = -2;
  }
  if (x < 0) {
    velocidadexBolinha = 2;
  }
}
